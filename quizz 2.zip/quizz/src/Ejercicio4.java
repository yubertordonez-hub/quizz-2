/**
 * Ejercicio 4: Clase Punto para un plano cartesiano 2D.
 * Ejecutar: java Ejercicio4.java
 */
public class Ejercicio4 {
    public static void main(String[] args) {
        Punto origen = new Punto();
        System.out.print("Punto en el origen: ");
        origen.mostrarCoordenadas();

        Punto p = new Punto(3, 4);
        System.out.print("Punto p: ");
        p.mostrarCoordenadas();
        System.out.println("Distancia de p al origen: " + p.calcularDistanciaDesdeOrigen());

        p.mover(2, -1);
        System.out.print("Después de mover(2, -1): ");
        p.mostrarCoordenadas();

        p.setX(0);
        p.setY(10);
        System.out.print("Después de setX(0) y setY(10): ");
        p.mostrarCoordenadas();
        System.out.println("getX() = " + p.getX() + ", getY() = " + p.getY());
        System.out.println("Distancia de p al origen: " + p.calcularDistanciaDesdeOrigen());
    }
}

class Punto {
    private double x;
    private double y;

    public Punto() {
        this(0, 0);
    }

    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() { return x; }
    public double getY() { return y; }

    public void setX(double nuevoX) { this.x = nuevoX; }
    public void setY(double nuevoY) { this.y = nuevoY; }

    public void mover(double deltaX, double deltaY) {
        x += deltaX;
        y += deltaY;
    }

    public double calcularDistanciaDesdeOrigen() {
        return Math.sqrt(x * x + y * y);
    }

    public void mostrarCoordenadas() {
        System.out.println("(" + x + ", " + y + ")");
    }
}
