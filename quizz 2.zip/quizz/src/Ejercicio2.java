import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Ejercicio 2: Sistema de Reservas de Salas de Reuniones.
 * Cada reserva dura 1 hora. Formato de fecha/hora: dd/MM/yyyy HH:mm
 * Ejecutar: java Ejercicio2.java
 */
public class Ejercicio2 {

    static final Logger LOG = Logger.getLogger("Reservas");
    static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    static void configurarLog() {
        try {
            LOG.setUseParentHandlers(false);
            FileHandler fh = new FileHandler("ejercicio2.log", true);
            fh.setFormatter(new SimpleFormatter());
            LOG.addHandler(fh);
        } catch (IOException e) {
            System.out.println("No se pudo crear el log: " + e.getMessage());
        }
    }

    // ---------- Modelo ----------
    static class Sala {
        final int id;
        final String nombre;
        final int capacidad;

        Sala(int id, String nombre, int capacidad) {
            this.id = id;
            this.nombre = nombre;
            this.capacidad = capacidad;
        }

        @Override
        public String toString() {
            return "Sala " + id + " - " + nombre + " (capacidad " + capacidad + ")";
        }
    }

    static class Reserva {
        final int id;
        final Sala sala;
        final LocalDateTime inicio; // duración fija: 1 hora
        final String reservante;
        final int asistentes;

        Reserva(int id, Sala sala, LocalDateTime inicio, String reservante, int asistentes) {
            this.id = id;
            this.sala = sala;
            this.inicio = inicio;
            this.reservante = reservante;
            this.asistentes = asistentes;
        }

        @Override
        public String toString() {
            return "Reserva #" + id + " | " + sala.nombre + " | " + inicio.format(FMT)
                    + " (1h) | " + reservante + " | " + asistentes + " asistentes";
        }
    }

    // ---------- Lógica ----------
    static class Sistema {
        static final int MAX_RESERVAS = 10;
        final List<Sala> salas = new ArrayList<>();
        final List<Reserva> reservas = new ArrayList<>();
        int siguienteId = 1;

        Sistema() {
            salas.add(new Sala(1, "Sala Norte", 6));
            salas.add(new Sala(2, "Sala Sur", 10));
            salas.add(new Sala(3, "Auditorio", 30));
        }

        Sala buscarSala(int id) {
            for (Sala s : salas) if (s.id == id) return s;
            return null;
        }

        boolean estaDisponible(Sala sala, LocalDateTime inicio) {
            for (Reserva r : reservas)
                if (r.sala.id == sala.id && r.inicio.equals(inicio)) return false;
            return true;
        }

        Reserva reservar(int idSala, LocalDateTime inicio, String nombre, int asistentes) {
            if (reservas.size() >= MAX_RESERVAS)
                throw new IllegalStateException("Se alcanzó el máximo de reservas (" + MAX_RESERVAS + ").");
            if (nombre == null || nombre.isBlank())
                throw new IllegalArgumentException("El nombre del reservante no puede estar vacío.");
            if (asistentes <= 0)
                throw new IllegalArgumentException("El número de asistentes debe ser mayor que 0.");
            if (inicio.isBefore(LocalDateTime.now()))
                throw new IllegalArgumentException("No se puede reservar en una fecha pasada.");
            Sala sala = buscarSala(idSala);
            if (sala == null) throw new IllegalArgumentException("La sala " + idSala + " no existe.");
            if (asistentes > sala.capacidad)
                throw new IllegalStateException("Capacidad excedida: la sala admite " + sala.capacidad + " personas.");
            if (!estaDisponible(sala, inicio))
                throw new IllegalStateException("La sala ya está reservada en ese horario.");
            Reserva r = new Reserva(siguienteId++, sala, inicio, nombre.trim(), asistentes);
            reservas.add(r);
            return r;
        }

        boolean cancelar(int idReserva) {
            return reservas.removeIf(r -> r.id == idReserva);
        }
    }

    // ---------- Entrada ----------
    static Scanner sc = new Scanner(System.in);

    static int leerEntero(String msg) {
        while (true) {
            System.out.print(msg);
            String l = sc.nextLine().trim();
            try {
                return Integer.parseInt(l);
            } catch (NumberFormatException e) {
                System.out.println("Error: ingrese un número entero.");
                LOG.warning("Entrada no numérica: '" + l + "'");
            }
        }
    }

    static LocalDateTime leerFechaHora(String msg) {
        while (true) {
            System.out.print(msg);
            String l = sc.nextLine().trim();
            try {
                return LocalDateTime.parse(l, FMT);
            } catch (DateTimeParseException e) {
                System.out.println("Formato inválido. Use dd/MM/yyyy HH:mm (ej. 15/12/2026 14:00).");
                LOG.warning("Fecha inválida: '" + l + "'");
            }
        }
    }

    // ---------- Opciones ----------
    static void listarSalas(Sistema s) {
        for (Sala sala : s.salas) System.out.println(sala);
    }

    static void crearReserva(Sistema s) {
        listarSalas(s);
        int idSala = leerEntero("ID de la sala: ");
        LocalDateTime inicio = leerFechaHora("Fecha y hora (dd/MM/yyyy HH:mm): ");
        System.out.print("Nombre de quien reserva: ");
        String nombre = sc.nextLine();
        int asistentes = leerEntero("Número de asistentes: ");
        try {
            Reserva r = s.reservar(idSala, inicio, nombre, asistentes);
            System.out.println("Reserva creada: " + r);
            LOG.info("Reserva creada: " + r);
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("No se pudo reservar: " + e.getMessage());
            LOG.warning("Reserva fallida: " + e.getMessage());
        }
    }

    static void consultarPorSala(Sistema s) {
        int idSala = leerEntero("ID de la sala: ");
        Sala sala = s.buscarSala(idSala);
        if (sala == null) {
            System.out.println("La sala no existe.");
            LOG.warning("Consulta de sala inexistente: " + idSala);
            return;
        }
        boolean hay = false;
        for (Reserva r : s.reservas)
            if (r.sala.id == idSala) { System.out.println(r); hay = true; }
        if (!hay) System.out.println("Sin reservas para esta sala.");
        LOG.info("Consulta de reservas por sala " + idSala);
    }

    static void consultarPorFecha(Sistema s) {
        while (true) {
            System.out.print("Fecha (dd/MM/yyyy): ");
            String l = sc.nextLine().trim();
            try {
                LocalDateTime d = LocalDateTime.parse(l + " 00:00", FMT);
                boolean hay = false;
                for (Reserva r : s.reservas)
                    if (r.inicio.toLocalDate().equals(d.toLocalDate())) { System.out.println(r); hay = true; }
                if (!hay) System.out.println("Sin reservas para esa fecha.");
                LOG.info("Consulta de reservas por fecha " + l);
                return;
            } catch (DateTimeParseException e) {
                System.out.println("Formato inválido. Use dd/MM/yyyy.");
                LOG.warning("Fecha inválida: '" + l + "'");
            }
        }
    }

    static void cancelarReserva(Sistema s) {
        int id = leerEntero("ID de la reserva a cancelar: ");
        if (s.cancelar(id)) {
            System.out.println("Reserva cancelada.");
            LOG.info("Reserva cancelada: " + id);
        } else {
            System.out.println("La reserva " + id + " no existe.");
            LOG.warning("Cancelación fallida, no existe: " + id);
        }
    }

    public static void main(String[] args) {
        configurarLog();
        Sistema sistema = new Sistema();
        LOG.info("Sistema de reservas iniciado.");
        int op;
        do {
            System.out.println("\n=== RESERVAS DE SALAS ===");
            System.out.println("1. Ver salas");
            System.out.println("2. Crear reserva");
            System.out.println("3. Consultar reservas por sala");
            System.out.println("4. Consultar reservas por fecha");
            System.out.println("5. Cancelar reserva");
            System.out.println("0. Salir");
            op = leerEntero("Opción: ");
            switch (op) {
                case 1 -> listarSalas(sistema);
                case 2 -> crearReserva(sistema);
                case 3 -> consultarPorSala(sistema);
                case 4 -> consultarPorFecha(sistema);
                case 5 -> cancelarReserva(sistema);
                case 0 -> System.out.println("Hasta luego.");
                default -> System.out.println("Opción inválida.");
            }
        } while (op != 0);
        LOG.info("Sistema de reservas finalizado.");
    }
}
