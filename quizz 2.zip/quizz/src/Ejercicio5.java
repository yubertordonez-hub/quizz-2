
public class Ejercicio5 {
    public static void main(String[] args) {
        Tarea t1 = new Tarea("Estudiar para el parcial");
        Tarea t2 = new Tarea("Entregar informe", 1);
        Tarea t3 = new Tarea("Ordenar el escritorio", 7); 

        t1.mostrarEstado();
        t2.mostrarEstado();
        t3.mostrarEstado();

        System.out.println();
        t1.setPrioridad(1);
        t3.setPrioridad(2); 
        t2.marcarComoCompletada();

        t1.mostrarEstado();
        t2.mostrarEstado();
        t3.mostrarEstado();
    }
}

class Tarea {
    private static final int PRIORIDAD_MIN = 1;
    private static final int PRIORIDAD_MAX = 3;
    private static final int PRIORIDAD_POR_DEFECTO = 2;

    private String descripcion;
    private int prioridad;
    private boolean completada;

    public Tarea(String descripcion) {
        this(descripcion, PRIORIDAD_POR_DEFECTO);
    }

    public Tarea(String descripcion, int prioridad) {
        this.descripcion = descripcion;
        if (prioridadValida(prioridad)) {
            this.prioridad = prioridad;
        } else {
            System.out.println("Prioridad " + prioridad + " inválida. Se usará la prioridad por defecto (2 - Media).");
            this.prioridad = PRIORIDAD_POR_DEFECTO;
        }
        this.completada = false;
    }

    private boolean prioridadValida(int p) {
        return p >= PRIORIDAD_MIN && p <= PRIORIDAD_MAX;
    }

    public String getDescripcion() { return descripcion; }
    public int getPrioridad() { return prioridad; }
    public boolean isCompletada() { return completada; }

    public void setPrioridad(int nuevaPrioridad) {
        if (prioridadValida(nuevaPrioridad)) {
            this.prioridad = nuevaPrioridad;
        } else {
            System.out.println("Prioridad inválida: debe estar entre 1 y 3. No se realizó el cambio.");
        }
    }

    public void marcarComoCompletada() {
        this.completada = true;
    }

    private String nombrePrioridad() {
        return switch (prioridad) {
            case 1 -> "Alta";
            case 2 -> "Media";
            default -> "Baja";
        };
    }

    public void mostrarEstado() {
        System.out.println("Tarea: " + descripcion
                + " | Prioridad: " + prioridad + " (" + nombrePrioridad() + ")"
                + " | Completada: " + (completada ? "Sí" : "No"));
    }
}
