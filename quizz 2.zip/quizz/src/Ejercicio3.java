import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Ejercicio 3: Gestión de Libros de una Pequeña Biblioteca (préstamo y devolución).
 * Ejecutar: java Ejercicio3.java
 */
public class Ejercicio3 {

    static final Logger LOG = Logger.getLogger("Biblioteca");

    static void configurarLog() {
        try {
            LOG.setUseParentHandlers(false);
            FileHandler fh = new FileHandler("ejercicio3.log", true);
            fh.setFormatter(new SimpleFormatter());
            LOG.addHandler(fh);
        } catch (IOException e) {
            System.out.println("No se pudo crear el log: " + e.getMessage());
        }
    }

    // ---------- Modelo ----------
    static class Libro {
        private final String titulo;
        private final String autor;
        private final String isbn;
        private final int copiasTotales;
        private int copiasDisponibles;

        Libro(String titulo, String autor, String isbn, int copias) {
            if (titulo == null || titulo.isBlank()) throw new IllegalArgumentException("El título es obligatorio.");
            if (autor == null || autor.isBlank()) throw new IllegalArgumentException("El autor es obligatorio.");
            if (isbn == null || isbn.isBlank()) throw new IllegalArgumentException("El ISBN es obligatorio.");
            if (copias < 0) throw new IllegalArgumentException("La cantidad de copias no puede ser negativa.");
            this.titulo = titulo.trim();
            this.autor = autor.trim();
            this.isbn = isbn.trim();
            this.copiasTotales = copias;
            this.copiasDisponibles = copias;
        }

        String getTitulo() { return titulo; }
        String getIsbn() { return isbn; }
        int getCopiasDisponibles() { return copiasDisponibles; }

        void prestar() {
            if (copiasDisponibles <= 0) throw new IllegalStateException("No hay copias disponibles de '" + titulo + "'.");
            copiasDisponibles--;
        }

        void devolver() {
            if (copiasDisponibles >= copiasTotales)
                throw new IllegalStateException("Todas las copias de '" + titulo + "' ya están en la biblioteca.");
            copiasDisponibles++;
        }

        @Override
        public String toString() {
            return titulo + " | " + autor + " | ISBN " + isbn
                    + " | disponibles: " + copiasDisponibles + "/" + copiasTotales;
        }
    }

    // ---------- Lógica ----------
    static class Biblioteca {
        static final int CAPACIDAD_MAXIMA = 5;
        private final List<Libro> catalogo = new ArrayList<>();

        void registrar(Libro l) {
            if (catalogo.size() >= CAPACIDAD_MAXIMA)
                throw new IllegalStateException("El catálogo está lleno (" + CAPACIDAD_MAXIMA + " libros).");
            if (buscarPorIsbn(l.getIsbn()) != null)
                throw new IllegalArgumentException("Ya existe un libro con el ISBN " + l.getIsbn() + ".");
            catalogo.add(l);
        }

        Libro buscarPorIsbn(String isbn) {
            for (Libro l : catalogo) if (l.getIsbn().equalsIgnoreCase(isbn.trim())) return l;
            return null;
        }

        Libro buscarPorTitulo(String titulo) {
            for (Libro l : catalogo) if (l.getTitulo().equalsIgnoreCase(titulo.trim())) return l;
            return null;
        }

        List<Libro> listar() { return catalogo; }
    }

    // ---------- Entrada ----------
    static Scanner sc = new Scanner(System.in);

    static int leerEntero(String msg) {
        while (true) {
            System.out.print(msg);
            String l = sc.nextLine().trim();
            try {
                return Integer.parseInt(l);
            } catch (NumberFormatException e) {
                System.out.println("Error: ingrese un número entero.");
                LOG.warning("Entrada no numérica: '" + l + "'");
            }
        }
    }

    static String leerTexto(String msg) {
        System.out.print(msg);
        return sc.nextLine();
    }

    // ---------- Opciones ----------
    static void registrarLibro(Biblioteca b) {
        String titulo = leerTexto("Título: ");
        String autor = leerTexto("Autor: ");
        String isbn = leerTexto("ISBN: ");
        int copias = leerEntero("Cantidad de copias: ");
        try {
            b.registrar(new Libro(titulo, autor, isbn, copias));
            System.out.println("Libro registrado.");
            LOG.info("Libro registrado: ISBN " + isbn);
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("No se pudo registrar: " + e.getMessage());
            LOG.warning("Registro fallido: " + e.getMessage());
        }
    }

    static void prestarLibro(Biblioteca b) {
        String isbn = leerTexto("ISBN del libro a prestar: ");
        Libro l = b.buscarPorIsbn(isbn);
        if (l == null) {
            System.out.println("El libro no existe.");
            LOG.warning("Préstamo fallido, ISBN inexistente: " + isbn);
            return;
        }
        try {
            l.prestar();
            System.out.println("Préstamo exitoso. Copias disponibles: " + l.getCopiasDisponibles());
            LOG.info("Préstamo: ISBN " + isbn);
        } catch (IllegalStateException e) {
            System.out.println("No se pudo prestar: " + e.getMessage());
            LOG.warning("Préstamo fallido ISBN " + isbn + ": " + e.getMessage());
        }
    }

    static void devolverLibro(Biblioteca b) {
        String isbn = leerTexto("ISBN del libro a devolver: ");
        Libro l = b.buscarPorIsbn(isbn);
        if (l == null) {
            System.out.println("El libro no existe.");
            LOG.warning("Devolución fallida, ISBN inexistente: " + isbn);
            return;
        }
        try {
            l.devolver();
            System.out.println("Devolución exitosa. Copias disponibles: " + l.getCopiasDisponibles());
            LOG.info("Devolución: ISBN " + isbn);
        } catch (IllegalStateException e) {
            System.out.println("No se pudo devolver: " + e.getMessage());
            LOG.warning("Devolución fallida ISBN " + isbn + ": " + e.getMessage());
        }
    }

    static void consultarLibro(Biblioteca b) {
        System.out.println("1. Buscar por ISBN\n2. Buscar por título");
        int op = leerEntero("Opción: ");
        Libro l;
        if (op == 1) l = b.buscarPorIsbn(leerTexto("ISBN: "));
        else if (op == 2) l = b.buscarPorTitulo(leerTexto("Título: "));
        else {
            System.out.println("Opción inválida.");
            return;
        }
        if (l == null) {
            System.out.println("Libro no encontrado.");
            LOG.warning("Consulta sin resultados.");
        } else {
            System.out.println(l);
            LOG.info("Consulta: ISBN " + l.getIsbn());
        }
    }

    static void listarLibros(Biblioteca b) {
        if (b.listar().isEmpty()) System.out.println("El catálogo está vacío.");
        else for (Libro l : b.listar()) System.out.println(l);
        LOG.info("Listado del catálogo (" + b.listar().size() + " libros)");
    }

    public static void main(String[] args) {
        configurarLog();
        Biblioteca biblioteca = new Biblioteca();
        LOG.info("Biblioteca iniciada.");
        int op;
        do {
            System.out.println("\n=== BIBLIOTECA ===");
            System.out.println("1. Registrar libro");
            System.out.println("2. Prestar libro");
            System.out.println("3. Devolver libro");
            System.out.println("4. Consultar libro");
            System.out.println("5. Listar libros");
            System.out.println("0. Salir");
            op = leerEntero("Opción: ");
            switch (op) {
                case 1 -> registrarLibro(biblioteca);
                case 2 -> prestarLibro(biblioteca);
                case 3 -> devolverLibro(biblioteca);
                case 4 -> consultarLibro(biblioteca);
                case 5 -> listarLibros(biblioteca);
                case 0 -> System.out.println("Hasta luego.");
                default -> System.out.println("Opción inválida.");
            }
        } while (op != 0);
        LOG.info("Biblioteca finalizada.");
    }
}
