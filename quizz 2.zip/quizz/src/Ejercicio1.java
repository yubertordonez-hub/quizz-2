import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Ejercicio 1: Sistema de Gestión de Recetas de Cocina.
 * Ejecutar: java Ejercicio1.java   (o botón "Run" en VS Code)
 */
public class Ejercicio1 {

    static final Logger LOG = Logger.getLogger("Recetas");

    static void configurarLog() {
        try {
            LOG.setUseParentHandlers(false); // no imprimir el log en consola
            FileHandler fh = new FileHandler("ejercicio1.log", true);
            fh.setFormatter(new SimpleFormatter());
            LOG.addHandler(fh);
        } catch (IOException e) {
            System.out.println("No se pudo crear el archivo de log: " + e.getMessage());
        }
    }

    // ---------- Clases del modelo ----------
    static class Ingrediente {
        private final String nombre;
        private final double cantidad;
        private final String unidad;

        Ingrediente(String nombre, double cantidad, String unidad) {
            if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Ingrediente sin nombre.");
            if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor que 0.");
            if (unidad == null || unidad.isBlank()) throw new IllegalArgumentException("Ingrediente sin unidad.");
            this.nombre = nombre.trim();
            this.cantidad = cantidad;
            this.unidad = unidad.trim();
        }

        @Override
        public String toString() {
            return cantidad + " " + unidad + " de " + nombre;
        }
    }

    static class Receta {
        private final String nombre;
        private final List<Ingrediente> ingredientes;
        private String instrucciones;
        private int porciones;

        Receta(String nombre, List<Ingrediente> ingredientes, String instrucciones, int porciones) {
            if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("El nombre no puede estar vacío.");
            if (ingredientes == null || ingredientes.isEmpty())
                throw new IllegalArgumentException("La receta debe tener al menos un ingrediente.");
            if (instrucciones == null || instrucciones.isBlank())
                throw new IllegalArgumentException("Las instrucciones no pueden estar vacías.");
            if (porciones <= 0) throw new IllegalArgumentException("Las porciones deben ser mayores que 0.");
            this.nombre = nombre.trim();
            this.ingredientes = ingredientes;
            this.instrucciones = instrucciones.trim();
            this.porciones = porciones;
        }

        String getNombre() { return nombre; }

        void setInstrucciones(String nuevas) {
            if (nuevas == null || nuevas.isBlank()) throw new IllegalArgumentException("Instrucciones inválidas.");
            this.instrucciones = nuevas.trim();
        }

        void setPorciones(int nuevas) {
            if (nuevas <= 0) throw new IllegalArgumentException("Las porciones deben ser mayores que 0.");
            this.porciones = nuevas;
        }

        void mostrar() {
            System.out.println("Receta: " + nombre + " (" + porciones + " porciones)");
            System.out.println("Ingredientes:");
            for (Ingrediente i : ingredientes) System.out.println("  - " + i);
            System.out.println("Instrucciones: " + instrucciones);
        }
    }

    // ---------- Lógica del sistema ----------
    static class GestorRecetas {
        private static final int CAPACIDAD_MAXIMA = 5;
        private final List<Receta> recetas = new ArrayList<>();

        void registrar(Receta r) {
            if (recetas.size() >= CAPACIDAD_MAXIMA)
                throw new IllegalStateException("Capacidad máxima alcanzada (" + CAPACIDAD_MAXIMA + " recetas).");
            if (buscar(r.getNombre()) != null)
                throw new IllegalArgumentException("Ya existe una receta con ese nombre.");
            recetas.add(r);
        }

        Receta buscar(String nombre) {
            for (Receta r : recetas)
                if (r.getNombre().equalsIgnoreCase(nombre.trim())) return r;
            return null;
        }

        List<Receta> listar() { return recetas; }
    }

    // ---------- Utilidades de entrada ----------
    static Scanner sc = new Scanner(System.in);

    static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = sc.nextLine().trim();
            try {
                return Integer.parseInt(linea);
            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un número entero.");
                LOG.warning("Entrada no numérica: '" + linea + "'");
            }
        }
    }

    static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = sc.nextLine().trim().replace(',', '.');
            try {
                return Double.parseDouble(linea);
            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un número válido.");
                LOG.warning("Entrada no numérica: '" + linea + "'");
            }
        }
    }

    static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }

    // ---------- Opciones del menú ----------
    static void registrarReceta(GestorRecetas g) {
        try {
            String nombre = leerTexto("Nombre de la receta: ");
            int porciones = leerEntero("Número de porciones: ");
            int n = leerEntero("¿Cuántos ingredientes? ");
            List<Ingrediente> ings = new ArrayList<>();
            for (int i = 1; i <= n; i++) {
                System.out.println("Ingrediente " + i + ":");
                String nom = leerTexto("  Nombre: ");
                double cant = leerDecimal("  Cantidad: ");
                String uni = leerTexto("  Unidad (g, ml, tazas...): ");
                ings.add(new Ingrediente(nom, cant, uni));
            }
            String instr = leerTexto("Instrucciones: ");
            g.registrar(new Receta(nombre, ings, instr, porciones));
            System.out.println("Receta registrada correctamente.");
            LOG.info("Receta registrada: " + nombre);
        } catch (IllegalArgumentException | IllegalStateException e) {
            System.out.println("No se pudo registrar: " + e.getMessage());
            LOG.log(Level.WARNING, "Fallo al registrar receta: " + e.getMessage());
        }
    }

    static void consultarReceta(GestorRecetas g) {
        String nombre = leerTexto("Nombre de la receta a buscar: ");
        Receta r = g.buscar(nombre);
        if (r == null) {
            System.out.println("La receta '" + nombre + "' no existe.");
            LOG.warning("Búsqueda fallida: " + nombre);
        } else {
            r.mostrar();
            LOG.info("Receta consultada: " + nombre);
        }
    }

    static void actualizarReceta(GestorRecetas g) {
        String nombre = leerTexto("Nombre de la receta a actualizar: ");
        Receta r = g.buscar(nombre);
        if (r == null) {
            System.out.println("La receta '" + nombre + "' no existe.");
            LOG.warning("Actualización fallida, no existe: " + nombre);
            return;
        }
        System.out.println("1. Cambiar instrucciones\n2. Cambiar porciones");
        int op = leerEntero("Opción: ");
        try {
            if (op == 1) {
                r.setInstrucciones(leerTexto("Nuevas instrucciones: "));
            } else if (op == 2) {
                r.setPorciones(leerEntero("Nuevas porciones: "));
            } else {
                System.out.println("Opción inválida.");
                return;
            }
            System.out.println("Receta actualizada.");
            LOG.info("Receta actualizada: " + nombre);
        } catch (IllegalArgumentException e) {
            System.out.println("No se pudo actualizar: " + e.getMessage());
            LOG.warning("Fallo al actualizar '" + nombre + "': " + e.getMessage());
        }
    }

    static void listarRecetas(GestorRecetas g) {
        if (g.listar().isEmpty()) {
            System.out.println("No hay recetas registradas.");
        } else {
            int i = 1;
            for (Receta r : g.listar()) {
                System.out.println("--- " + i++ + " ---");
                r.mostrar();
            }
        }
        LOG.info("Listado de recetas (" + g.listar().size() + ")");
    }

    public static void main(String[] args) {
        configurarLog();
        GestorRecetas gestor = new GestorRecetas();
        LOG.info("Sistema de recetas iniciado.");
        int opcion;
        do {
            System.out.println("\n=== GESTIÓN DE RECETAS ===");
            System.out.println("1. Registrar receta");
            System.out.println("2. Consultar receta");
            System.out.println("3. Actualizar receta");
            System.out.println("4. Listar recetas");
            System.out.println("0. Salir");
            opcion = leerEntero("Opción: ");
            switch (opcion) {
                case 1 -> registrarReceta(gestor);
                case 2 -> consultarReceta(gestor);
                case 3 -> actualizarReceta(gestor);
                case 4 -> listarRecetas(gestor);
                case 0 -> System.out.println("Hasta luego.");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
        LOG.info("Sistema de recetas finalizado.");
    }
}
